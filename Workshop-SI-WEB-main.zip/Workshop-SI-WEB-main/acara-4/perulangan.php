<?php
for ($i = 100; $i <= 1000; $i++) 
{
    echo "i ke - $i \n";
}