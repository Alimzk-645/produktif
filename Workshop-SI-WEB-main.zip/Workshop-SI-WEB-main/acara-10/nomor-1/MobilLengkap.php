<?php
class mobilLengkap {

    public function nontonTV() {
        echo "TV dihidupkan\n";
    }


    public function hidupkanMobil() {
        echo "Hidupkan Mobil\n";
    }


    public function matikanMobil() {
        echo "Matikan Mobil\n";
    }


    public function ubahGigi() {
        echo "Ubah gigi mobil\n";
    }
}