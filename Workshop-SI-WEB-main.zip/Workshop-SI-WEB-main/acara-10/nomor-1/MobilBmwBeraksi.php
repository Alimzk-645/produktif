<?php
class MobilBMWberaksi {
    public function nontonTV(MobilBMW $mobil) {
        $mobil->nontonTV();
    }

    public function hidupkanMobil(MobilBMW $mobil) {
        $mobil->hidupkanMobil();
    }

    public function matikanMobil(MobilBMW $mobil) {
        $mobil->matikanMobil();
    }

    public function ubahGigi(MobilBMW $mobil) {
        $mobil->ubahGigi();
    }
}