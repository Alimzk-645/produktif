<?php
class person
{
    protected $name;
    function set_name($new_name)
    {
        $this->name = $new_name;
    }
    function get_name()
    {
        return $this->name;
    }
}
