<?php
include("person.php");

$person1 = new Person();
// set value dari properti name
$person1->set_name('Lukman Hakim');
// akses value dari properti name
echo $person1->get_name();
// properti tidak bisa di akses secara langsung
echo "Hai " . $person1->name = 'Taufiq Rizaldi';
echo "<hr>";
