<?php
// Contoh penggunaan operator ("/")
$angka1 = 10;
$angka2 = 2;
echo $angka1/$angka2; // hasilnya 10 / 2 = 5

// Contoh penggunaan operator ("%")
$angka3 = 7;
$angka4 = 2;
echo $angka3 % $angka4; // hasilnya 7 % 2 = 1