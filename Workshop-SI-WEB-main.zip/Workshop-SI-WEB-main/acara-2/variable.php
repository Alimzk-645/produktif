<?php
$nim="E41231969";
$nama="Ilman Nafian";
$prodi="Teknik Informatika";
echo "Selamat Praktikum $nama\n";
echo "$nim\n";
echo "$nama\n";
echo $prodi;