<?php 
$x = 5985;
var_dump($x);
echo "<br>"; 
$x = -345; // angka negatif 
var_dump($x);
echo "<br>"; 
$x = 0x8C; // angka hexadecimal
var_dump($x);
echo "<br>";
$x = 047; // angka octal
var_dump($x);
echo "<br>";
$x = 10.365;
var_dump($x);
echo "<br>"; 
$x = 2.4e3;
var_dump($x);
echo "<br>"; 
$x = 8E-5;
var_dump($x);
echo "<br>";
echo strlen("Hello world!");
echo strpos("Hello world!","world");
?>