<?php 
$x=10; 
$y=6;
echo ($x + $y); 
echo ($x - $y); 
echo ($x * $y); 
echo ($x / $y); 
echo ($x % $y); 
$a = "Hello";
$b = $a . " world!";
echo $b; 
Echo $a. "--" . $b. " ini string operator ";
?>
