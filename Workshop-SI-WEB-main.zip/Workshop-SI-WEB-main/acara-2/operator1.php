<?php
$tugas1=90;
$tugas2=80;
$jumlah=$tugas1 + $tugas2;
$rerata=$jumlah/2 ;
echo "Nilai Tugas I :".$tugas1."<br>";
echo "Nilai Tugas II:".$tugas2."<br>";
echo "Jumlah Tugas :".$jumlah."<br>";
echo "Rerata Tugas :".$rerata;
echo "<br>";
// menambahkan operator penggabungan string (".")
$gabung = "Hasil penggabungan : " .$tugas1 . $tugas2;
echo $gabung;
?>