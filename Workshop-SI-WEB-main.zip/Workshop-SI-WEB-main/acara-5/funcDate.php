<?php
$tanggal = date('d-F-Y');
echo $tanggal;